<!DOCTYPE html>
<html lang="en">
<?php include 'head.php';?>
<body>
    <header>
        <h2>Data Mahasiswa</h2>
    </header>
    <section>
        <?php 
            include 'menu.php';
            include 'raffimahasiswatambah2.php'
        ?>
    </section>
    <?php include 'footer.php';?>
</body>
</html>