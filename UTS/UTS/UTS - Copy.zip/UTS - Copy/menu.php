<nav>
    <ul>
        <li><a href="index.php">Beranda</a></li>
        <li><a href="dosen.php">Data Dosen</a></li>
        <li><a href="mahasiswa.php">Data Mahasiswa</a></li>
        <li><a href="matakuliah.php">Data Mata Kuliah</a></li>
    </ul>
</nav>