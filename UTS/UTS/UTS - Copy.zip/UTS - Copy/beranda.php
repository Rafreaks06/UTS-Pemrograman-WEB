<article>
    <h1>Global Institute</h1>
    <p>“Welcome, the best students and future great leaders of Indonesia, to the Global Institute.”</p>
    <p>Global Institute of Technology and Business adalah kampus modern yang menggabungkan keunggulan di bidang teknologi dan bisnis untuk menciptakan
         lulusan siap bersaing di panggung global. Dengan kurikulum berbasis industri dan 
        fasilitas terkini, Global Institute membekali mahasiswa dengan keterampilan digital, analisis bisnis, dan kepemimpinan yang dibutuhkan di era disruptif.</p>
</article>