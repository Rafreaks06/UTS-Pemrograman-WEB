<style>
    .p{
        position: relative;
        margin-top:60px;    
    }
    .footer{
        margin-bottom:30px;
    }
</style>


<footer>
    <p>Created By: Muhammad Raffi Ar-rosyid | 1124160189 | Teknik Informatika</p>
</footer>