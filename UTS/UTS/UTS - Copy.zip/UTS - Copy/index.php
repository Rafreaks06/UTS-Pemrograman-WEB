<!DOCTYPE html>
<html lang="en">
<?php include 'head.php';?>
<body>
    <header>
        <h2>Kartu Studi Tetap</h2>
    </header>
    <section>
        <?php 
            include 'menu.php';
            include 'beranda.php'
        ?>
    </section>
    <?php include 'footer.php';?>
</body>
</html>