<!DOCTYPE html>
<html lang="en">
<?php include 'head.php';?>
<body>
    <header>
        <h2>Data Dosen</h2>
    </header>
    <section>
        <?php 
            include 'menu.php';
            include 'raffidosen.php'
        ?>
    </section>
    <?php include 'footer.php';?>
</body>
</html>