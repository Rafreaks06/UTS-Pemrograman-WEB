<?php
    $koneksi = mysqli_connect("localhost","root","", "raffikst")
?>